package de.tuhh.diss.harborstorage;

import de.tuhh.diss.harborstorage.sim.PhysicalCrane;
import de.tuhh.diss.harborstorage.sim.StorageElement;

public class CraneControl {
	//private static final double TOL = 0.01;
	PhysicalCrane myCrane;
	
	public CraneControl(PhysicalCrane cr){
		myCrane = cr;
	}
	
	/**
	 * Moves the crane to the given position and stores the given packet.
	 * 
	 * @param x          Position in the X-Axis.
	 * @param y          Position in the Y-Axis.
	 * @param packet	 Packet desired to be stored.
	 */
	public void storePacket(int x, int y, StorageElement packet) {
		myCrane.start();
		//First go to loading position
		moveToX(myCrane.getLoadingPosX());
		moveToY(myCrane.getLoadingPosY());
		//pick up the packet
		myCrane.loadElement(packet);
		//drive to chosen slot
		moveToX(x);
		moveToY(y);
		//store the package
		myCrane.storeElement();
		//return to unloading point
		moveToX(myCrane.getLoadingPosX());
		moveToY(myCrane.getLoadingPosY());
		
	}
	/**
	 * Moves the crane to the given position and retrieves the packet from given position.
	 * 
	 * @param x   Position in the X-Axis.
	 * @param y	  Position in the Y-Axis.
	 * @return	  Returns the retrieved Storage Element
	 */
	public StorageElement retrievePacket(int x, int y) {
		
		//drive to chosen slot
		moveToX(x);
		moveToY(y);
		//retrieve
		myCrane.retrieveElement();
		//return to unloading point
		moveToX(myCrane.getLoadingPosX());
		moveToY(myCrane.getLoadingPosY());
		//unload element		
		return myCrane.unloadElement();  
	}
	
	public void shutdown() {
		myCrane.shutdown();
		
	}
	
	private void moveToX(int x){
		myCrane.start();
		
		while(x > myCrane.getPositionX()){
			myCrane.forward();
		}
		//myCrane.stopX();
		while(x < myCrane.getPositionX()){
			myCrane.backward();
		}
		myCrane.stopX();
	}
	private void moveToY(int y){
		myCrane.start();
				
		while(y > myCrane.getPositionY()){
			myCrane.up();
		}
		while(y < myCrane.getPositionY()){
			myCrane.down();
		}
		
		myCrane.stopY();
		
	}
}
