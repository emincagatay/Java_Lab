package de.tuhh.diss.harborstorage;

import de.tuhh.diss.harborstorage.sim.StoragePlace;

public class Slot implements StoragePlace {	
	
	private int number;
	private int positionX;
	private int positionY;
	private int width;
	private int height;
	private int depth;
	private int loadCapacity;
	private Packet containedPacket = null; 
	
	
	
	/**
	 * This constructor has introduced to obtain the information of a StoragePlace Array which is located
	 * inside of the provided class of PhysicalHarborStorage
	 */
	public Slot(StoragePlace sp){
		number =sp.getNumber();
		positionX =sp.getPositionX();
		positionY =sp.getPositionY();
		width = sp.getWidth();
		height = sp.getHeight();
		depth = sp.getDepth();
		loadCapacity = sp.getLoadCapacity();
	}
	
	
	public Slot(Slot a){
		
			number =a.getNumber();
			positionX =a.getPositionX();
			positionY =a.getPositionY();
			width = a.getWidth();
			height = a.getHeight();
			depth = a.getDepth();
			loadCapacity = a.getLoadCapacity();
			
		

	}
	//This constructor is defined to allow to create a NULL Slot.
	public Slot(){
		
	}
	public int getNumber() {
		
		return number; 
	}
	
	public int getWidth() {
		return width;  
	}
	
	public int getHeight() {
		return height; 
	}
		
	public int getDepth() {
		return depth;  
	}
	
	public int getLoadCapacity() {
		return loadCapacity; 
	}
	
	public int getPositionX() {
		return positionX; 
	}
	
	public int getPositionY() {
		return positionY; 
	}
	public void setContainedPacket(Packet p){
		containedPacket = p;
	}
	public Packet getContainedPacket(){
		return containedPacket;
	}

}
