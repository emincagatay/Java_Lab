package de.tuhh.diss.harborstorage;

import de.tuhh.diss.harborstorage.sim.StorageException;
import de.tuhh.diss.io.SimpleIO;


public class HarborStorageApp extends HarborStorageManagement {
	private static HarborStorageManagement hsm;
	
	/** Displays the possible operations than can be performed the program.Obtains the operation by the user input.
	 * 
	 * @return		Returns the user's choice
	 */
	public static int getChoice(){
		int choice = 0;
		
		String line2 = new String("*** Main Menu ***");
		String prog_exp = new String("0: Quit program\n"+"1: Store a packet in the highbaystorage\n"+
		"2: Retrieve a packet from the highbaystorage\n"+"Your choice:");
		SimpleIO.println("\n\n"+line2+"\n");		
		SimpleIO.println(prog_exp);
		choice = SimpleIO.readInteger();
		
		return choice;
		
	}
	/**
	 * Obtains the parameters of the packet by user input.
	 * Stores the packet using storePacket method and displays the ID of the stored packet when the conditions are met.	 *  
	 * 
	 * @param hsm	HarborStorageManagement 
	 * @return		Returns true if the packet has stored.Otherwise returns false.
	 */
	public static boolean opt1(HarborStorageManagement hsm){
		String descrp = null;
		int[] dims = new int[4];
		Packet[] PacketArray = hsm.getPackets();
		
		String choice1 = new String("*** Store a Packet ***");
		SimpleIO.println("\n"+choice1+"\n"+"Description:");
		descrp = SimpleIO.readString();
		for(int i = 0; i<PacketArray.length;i++){
			while(descrp.equals(PacketArray[i].getDescription())){//checks if the entered description is unique.
				SimpleIO.println("\nTHere is already a packet named '"+descrp+"'. Please enter another description for the new packet:");
				descrp = SimpleIO.readString();
				i=0;
			}						
		}
		
		//Obtains the parameters of the packet.
		SimpleIO.println("Width:");
		dims[0] = SimpleIO.readInteger();
		SimpleIO.println("Height:");
		dims[1] = SimpleIO.readInteger();
		SimpleIO.println("Depth:");
		dims[2] = SimpleIO.readInteger();
		SimpleIO.println("Weight:");
		dims[3] = SimpleIO.readInteger();
		SimpleIO.println("You entered packet"+"'"+descrp+"'"+" of size "+dims[0]+"x"+dims[1]+"x"+dims[2]+"and weight "+ dims[3]+".");
		SimpleIO.println("\nShall we store the packet? (y/n): ");
		String str_decision = SimpleIO.readString();
		char decision = str_decision.charAt(0);
		while(decision != 'y' && decision != 'n'){//checks if the user enters an undefined operation.
			SimpleIO.println("\nYou entered a undefined operation. Please enter y for YES and n for NO!: ");
			str_decision = SimpleIO.readString();
			decision = str_decision.charAt(0);
		}
		if(decision == 'y'){
			
				try{
					int ID = hsm.storePacket(dims[0], dims[1], dims[2], descrp, dims[3]);//stores the packet
					SimpleIO.println("Packet stored in rack. The ID is "+ID);
				}
				catch(StorageException e){
					SimpleIO.println(e.getMessage());//throws an exception if storage is not possible.	
					return false;
				}				
			}			
		
		else{
			SimpleIO.println("\nOperation has aborted. Going back to the main menu...\n");
			return false;
		}
		return true;
	}
	
	/**
	 * Obtains the parameters of the packet by user input.
	 * Retrieves the packet using retrievePacket when the conditions are met.	 
	 * 
	 * @param hsm	HarborStorageManagement Object 
	 * @return		Returns true if the packet has retrieved.Otherwise returns false.
	 */
	public static boolean opt2(HarborStorageManagement hsm){
		String descrp = null;
		Packet[] PacketArray = hsm.getPackets();		
		if(PacketArray.length > 0){//Checks if there are any packets to retrieve
			SimpleIO.println("\nAvailable Packets:\n");
			for(int i = 0; i<PacketArray.length;i++){//Displays the available packets to retrieve.
				SimpleIO.println((i+1)+": Packet '"+PacketArray[i].getDescription()+"' Size: "+ 
			PacketArray[i].getWidth()+"x"+PacketArray[i].getHeight()+"x"+PacketArray[i].getDepth()+
			" Weight: "+PacketArray[i].getWeight());
			}
			SimpleIO.println("\n*** Enter description of the packet to be retrieved (0 = Abort) ***");
			descrp = SimpleIO.readString();
			char c = descrp.charAt(0);
			if(c == '0'){
				SimpleIO.println("\nOperation has aborted. Going back to the main menu...\n");
				return false;
			}
			else{
				try{
					hsm.retrievePacket(descrp);//retrieves the desired packet.
				}
				catch(StorageException e){
					SimpleIO.println(e.getMessage());//Throws an exception if the given packet has not been stored.
					return false;
				}
			}
		}
		else{
			SimpleIO.println("There is not any stored packet to retrieve in highbaystorage.");
			return false;
		}
		return true;
	}
	/**
	 * Main method is the user interface. 
	 * Performs the operations requested by the user. 
	 */
		
	public static void main (String[] args) {
		hsm = new HarborStorageManagement();
		String entrance = new String("Welcome to TUHH/DISS Harbor Storage Management");
		SimpleIO.println("\n"+entrance);
		
		int choice;		
		choice = getChoice();
		// Runs the user interface until the user wants to close the program
		while(choice != 0){
			//Checks the desired operation of the user
			if(choice == 1){
				opt1(hsm);
				
			}		
			else if (choice == 2){
				if(opt2(hsm)== true){
					SimpleIO.println("Packet retrieved");
				}
				else{					
					choice = getChoice();
					continue;
				}						
			}
			else{
				SimpleIO.println("You entered a undefined operation. Going back to main menu...");
				choice = getChoice();
				continue;
			}
			choice = getChoice();
		}
		SimpleIO.println("System ends.");
		hsm.shutdown();
		
	}

	
	
	
}
