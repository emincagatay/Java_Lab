package de.tuhh.diss.harborstorage;

import de.tuhh.diss.harborstorage.sim.HighBayStorage;
import de.tuhh.diss.harborstorage.sim.StorageException;
import de.tuhh.diss.harborstorage.sim.PhysicalCrane;
import de.tuhh.diss.harborstorage.sim.PhysicalHarborStorage;
import de.tuhh.diss.harborstorage.sim.StoragePlace;


public class HarborStorageManagement implements HighBayStorage {
	
	private PhysicalHarborStorage myPhyStorage;
	private PhysicalCrane myCrane;
	private CraneControl myCraneControl;
	private Packet[] myPacketArray;
	private Slot[] mySlots;
	private StoragePlace[] aux; 
	
	
	public HarborStorageManagement(){
		myPhyStorage = new PhysicalHarborStorage();
		myCrane = myPhyStorage.getCrane();
		myCraneControl = new CraneControl(myCrane);
		myPacketArray = new Packet[0];
		mySlots = new Slot[myPhyStorage.getStoragePlacesAsArray().length];		
		aux = myPhyStorage.getStoragePlacesAsArray();
		
		for(int i =0; i<myPhyStorage.getStoragePlacesAsArray().length; i++){
			mySlots[i] = new Slot(aux[i]);
		}	
	}	
	/**
	 * Stores the given packet. ID of the packet is returned.
	 * 
	 * @param width          width of the given packet.
	 * @param height         height of the given packet.
	 * @param depth       	 depth of the given packet.
	 * @param description 	 description of the given packet.
	 * @param weight         weight of the given packet.
	 * @return               Returns ID of the stored packet unless there is a storage exception.
	 */
	public int storePacket(int width, int height, int depth, String description, int weight) throws StorageException {
		
		int ID = myPacketArray.length + 1;		
		Packet p = new Packet(width, height, depth, description, weight, ID);
		try{
			Slot size = findSuitableSlot(p);
			if(size != null){			
				Slot s = new Slot(size);
				myCraneControl.storePacket(s.getPositionX(), s.getPositionY(), p);			
				for(int i = 0; i<mySlots.length; i++){
					if(mySlots[i] == size){
						mySlots[i].setContainedPacket(p);												
						break;													
						}
				}
				myPacketArray =increasePacketArray(myPacketArray, p);				
				return ID;										
			    
			}
			else{
					
				throw new StorageException("\nPacket cannot be stored.Either it's too large. Returning to the Main Menu...\n");				
			}		
		}
		
		catch(StorageException e){
			throw new StorageException("\n"+e.getMessage());
		}			
	}
	
	/**
	 * Retrieves the stored packet. Throws exception if there is not any packet in the harbor storage.
	 * 
	 * @param description          description of packet which is desired to retrieve.
	 */
		
	public void retrievePacket(String description) throws StorageException {	
		Packet desiredPacket=null;
		Slot desiredSlot =null;
		
		for(int i = 0; i<mySlots.length; i++){
			if(mySlots[i].getContainedPacket()!= null){
				if( mySlots[i].getContainedPacket().getDescription().equals(description)){
					desiredPacket = mySlots[i].getContainedPacket();
					desiredSlot = mySlots[i];
				}
			}
		}
		
		if(desiredPacket == null){
			throw new StorageException("\nThis packet has not been stored. Returning to the Main Menu...");
		}
		else{
			myCraneControl.retrievePacket(desiredSlot.getPositionX(), desiredSlot.getPositionY());
			
			for(int j = 0; j < mySlots.length; j++){
				if(mySlots[j] == desiredSlot){
					mySlots[j].setContainedPacket(null);
					myPacketArray = decreasePacketArray(myPacketArray,desiredPacket);					
				}			
			}
		}		
	}
	/**
	 * Finds the suitable slot for the given packet. 
	 * Throws exception if either there is not any available slot  in the harbor storage or the storage is full.
	 * 
	 * @param p          Packet that is desired to be loaded to the storage.
	 * @return           Returns the most available slot in the storage.
	 */
	private Slot findSuitableSlot(Packet p) throws StorageException {		
		
		if(myPacketArray.length < 29 ){
			Slot[] suitableSlots = new Slot[0];
			for(int i = 0; i < mySlots.length; i++){
				if(mySlots[i].getContainedPacket()==null){					
					if(mySlots[i].getLoadCapacity() >= p.getWeight()){
						if(mySlots[i].getWidth() >= p.getWidth()){
							if(mySlots[i].getHeight() >= p.getHeight()){ 
								if(mySlots[i].getDepth()>= p.getDepth()){ 							
								suitableSlots = increaseSlotArray(suitableSlots, mySlots[i]);
								}							
							}						
						}
					}
				}				
			}
			//Finds best spot for the given load by minimizing the wasted area and weight
			Slot bestSlot = new Slot();			
			if(suitableSlots.length > 1){
		
				int[] waste = new int[suitableSlots.length];					
				for(int j=0; j<suitableSlots.length; j++){					
					int heightDiff = suitableSlots[j].getHeight() - p.getHeight();
					int widthDiff = suitableSlots[j].getWidth() - p.getWidth();
					int depthDiff = suitableSlots[j].getDepth()- p.getDepth();
					int weightDiff = suitableSlots[j].getLoadCapacity() - p.getWeight();					
					waste[j] = heightDiff * widthDiff * depthDiff + weightDiff;
				}				
				int min_waste = waste[0];
				for(int k=1; k<suitableSlots.length; k++){					
					if(waste[k] < waste[k-1] ){
						if(min_waste > waste[k]){
							min_waste = waste[k];							
							bestSlot = suitableSlots[k];													
						}
					}
				}
			}
			else if(suitableSlots.length == 1){
				bestSlot = suitableSlots[0];
			}
			else{					
				throw new StorageException("There is no avalaible place to store the desired packet.\n");											
			}
			return bestSlot;			
		}
		else{			
			throw new StorageException("Storage is full.\n");	
		}		
	}
		
	public Packet[] getPackets() {
				
		return myPacketArray; 	
	}
			
	private Slot[] increaseSlotArray(Slot[] initialArray, Slot lastItem){
		int size = initialArray.length;
		Slot[] finalArray = new Slot[size+1];
		for(int i=0; i < size; i++){
			finalArray[i] = initialArray[i];
		}
		finalArray[size] = lastItem;
		
		return finalArray;
	
	}
	private Packet[] increasePacketArray(Packet[] initialArray, Packet lastItem){
		int size = initialArray.length;
		
		Packet[] finalArray = new Packet[size+1];
		if(size == 0){
			finalArray[size] = lastItem;
		}
		else{
			for(int i=0; i < size; i++){
				finalArray[i] = initialArray[i];
			}
			finalArray[size] = lastItem;
		}
		
		
		return finalArray;
	
	}
	
	private Packet[] decreasePacketArray(Packet[] array1, Packet pack1){
		int size = array1.length;		
		Packet[] array2 = new Packet[size-1];
		for(int i = 0; i < size-1; i++){
			array2[i]=array1[i];
			if(array1[i]== pack1){
				for(int j = i;j<array2.length;j++){
					array2[j] = array1[j+1];
				}
				break;
			}
			
			
		}
		return array2;
		
	}
	
	public void shutdown() {
		myCrane.shutdown();	
	}
	
}
