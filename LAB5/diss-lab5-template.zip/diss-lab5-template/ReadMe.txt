In this file you shall write things your tutor/lecturer must/should know 
(e.g. about your program and who you are).

This solution was produced by: 

1. Family name, given name, student identication number, degree program
2. Family name, given name, student identication number, degree program 
3. Family name, given name, student identication number, degree program

Interviews were done in group: (1=Mo,11:30, 2=Mo,13:15, 3=Fr,9:45)

(Space for comments.)
	
