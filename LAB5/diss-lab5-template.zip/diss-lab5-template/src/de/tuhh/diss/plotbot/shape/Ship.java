package de.tuhh.diss.plotbot.shape;

import de.tuhh.diss.plotbot.shape.Plottable;
import de.tuhh.diss.plotbot.PlotbotControl;

public class Ship implements Plottable{
	public void plot(PlotbotControl pc){
		// put your plot routine in here
	}
}
